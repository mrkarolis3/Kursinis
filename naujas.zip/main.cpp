#include <iostream>
#include <ctime>
#include <cstdlib>
#include <string>
#include <unistd.h>
#include "pabaiga.h"
#include <stdlib.h> 
#include <vector>
using namespace std;

void pabaiga();

class zaidimas
{
  private:
  char lent[10][10];
  char z,kryptis;
  int x,y,laisva, kieklaivu=10, pat=0, pat1=-1, pat2=-1, kryp=0, kk=1;
  vector <int> laiveliai;

  //tuscia vieta - . (taskas)
  //laivas bus - @
  //pataikyas laivas - x
  //nepataikyta vieta - o

  public:

  zaidimas()
  {
    for (int i=0;i<10;i++)
    {
      for (int j=0;j<10;j++)
      lent[i][j]='.';
    }
  }

  void lentspaus()
  {
    cout<<"   A B C D E F G H I J"<<endl;
    for (int i=0;i<10;i++)//pirmas atsakingas uz vertikalu spausdinima
    {
      cout<<i+1<<" ";
      if (i+1!=10)
      cout<<" ";
      for (int j=0;j<10;j++)//antras uz horizontalu
      {
        if(lent[i][j]=='x' || lent[i][j]=='X')
        cout<<"\033[38;5;9m"<<lent[i][j]<<"\033[0m"<<" ";        
        else  if(lent[i][j]=='o')
        cout<<"\033[38;5;176m"<<lent[i][j]<<"\033[0m"<<" ";     
        else  if(lent[i][j]=='@')
        cout<<"\033[38;5;14m"<<lent[i][j]<<"\033[0m"<<" ";     
        else
        cout<<lent[i][j]<<" ";
      }
      cout<<endl;
    }
      cout<<endl;
  }

  void laivuivedimaskompiuteris()
  {
    for (int i=4;i>0;i--)// ima 4 skiringu dydziu laivus
    {
      for (int j=0;j<5-i;j++)// kiek kartu reikia kiekvieno laivo
      {
      x=rand()%10+1;
      y=rand()%10+1;
      kryptis=rand()%2;
      laisva=0;
      if (kryptis==1)
      {
          kryptis='A';

      }
      if (kryptis==0)
      {
          kryptis='D';
      }
        // pasiverciu raide i skaiciu
        if (kryptis=='A' && (x+i-1)<=10 )
        {
          for (int p=x-1;p<=x+i;p++)
          {
              for (int u=y-1;u<=y+1;u++)
              {
                  if (lent[p-1][u-1]=='.' || p<1 || p>10 || u<1 || u>10)
                      laisva++;
              }
          }
          if (laisva==(i+2)*3)
          {
              for (int k=0;k<i;k++)
              {
                lent[x-1+k][y-1]='@';
              }
          }
          else
          {
              j--;
          }
        }
        else if (kryptis=='D' && (y+i-1)<=10)
        {
            for (int p=x-1;p<=x+1;p++)
          {
              for (int u=y-1;u<=y+i;u++)
              {
                  if (lent[p-1][u-1]=='.' || p<1 || p>10 || u<1 || u>10)
                      laisva++;
              }
          }
          if (laisva==(i+2)*3)
          {
              for (int k=0;k<i;k++)
              {
                lent[x-1][y-1+k]='@';
              }
          }
          else
          {
              j--;
          }
        }
        else
        {
            j--;
        }
      }
    }
  }

  void operator ++()//manoivedimas
  {
    for (int i=4;i>0;i--)// ima 4 skiringu dydziu laivus
    {
      for (int j=0;j<5-i;j++)// kiek kartu reikia kiekvieno laivo
      {
        lentspaus();
        cout<<"Įvesite koordinates, kur norite padėti savo "<<i<<"-ietį laivą. (Pavyzdžiui 4 A arba 7 E) "<<endl;
        cin>>x>>z;
        cout<<"Kokia kryptimi norite, kad jūsų laivas būtų? (A - apačia, D - dešinė)"<<endl;
        cin>>kryptis;
        cout<<"\033[2J\033[1;1H";
        z=toupper(z);
        kryptis=toupper(kryptis);
        //jei ivedate mazaja raide o ne didziaja
        y=z-64;
        laisva=0;
        // pasiverciu raide i skaiciu
        if (kryptis=='A' && (x+i-1)<=10 && y<=10)
        {
          for (int p=x-1;p<=x+i;p++)
          {
              for (int u=y-1;u<=y+1;u++)
              {
                  if (lent[p-1][u-1]=='.' || p<1 || p>10 || u<1 || u>10)
                      laisva++;
              }
          }
          if (laisva==(i+2)*3)
          {
              for (int k=0;k<i;k++)
              {
                lent[x-1+k][y-1]='@';
              }
          }
          else
          {
              cout<<"Blogai nurodete koordinates!"<<endl<<endl;
              j--;
          }
        }
        else if (kryptis=='D' && (y+i-1)<=10 && x<=10)
        {
            for (int p=x-1;p<=x+1;p++)
          {
              for (int u=y-1;u<=y+i;u++)
              {
                  if (lent[p-1][u-1]=='.' || p<1 || p>10 || u<1 || u>10)
                      laisva++;
              }
          }
          if (laisva==(i+2)*3)
          {
              for (int k=0;k<i;k++)
              {
                lent[x-1][y-1+k]='@';
              }
          }
          else
          {
              cout<<"Blogai nurodete koordinates"<<endl<<endl;
              j--;
          }
        }
        else
        {
            cout<<"Blogai nurodete koordinates"<<endl<<endl;
            j--;
        }
      }
    }
    cout<<"Jūsų lentelė jau užpildyta!";
  }
    void priesasnepataike(zaidimas A, int x, int y)
    {
      cout<<"\033[2J\033[1;1H";
      cout<<"Priešininkas nepataikė :)"<<endl;
      lent[x][y]='o';
      cout<<endl<<endl<<"Mano lentelė:"<<endl;
      lentspaus();
      cout<<endl<<endl<<"Priešininko lentelė:"<<endl;
      A.lentspaus();


    }

  void kompiuterissuvis(zaidimas A)/////////
  {
    if(pat==0)
      {  
        x=rand()%10+1;
        y=rand()%10+1;
        if(lent[x-1][y-1]=='.')
        {
          priesasnepataike(A, x-1,y-1);
        }
        else if(lent[x-1][y-1]=='o' || lent[x-1][y-1]=='x'  || lent[x-1][y-1]=='X')
        {
          kompiuterissuvis(A);
        }
        else if(lent[x-1][y-1]=='@')
        {
          cout<<"\033[2J\033[1;1H";
          cout<<"Priešininkas pataikė :("<<endl;
          lent[x-1][y-1]='x';
          pat1=x-1;
          pat2=y-1;   
          pat=1;
          if(arsunaikintaslaivas(lent, x-1,y-1)!=1)
          {
            pat=0;
            kieklaivu--;
            cout<<"Ir sunaikino visą laivą!"<<endl;
            sunaikintaslaivas(lent, x-1,y-1,0);
            
          }
            cout<<endl<<endl<<"Mano lentelė:"<<endl;
            lentspaus();
            cout<<endl<<endl<<"Priešininko lentelė:"<<endl;
            A.lentspaus();

            sleep(2);  
            kompiuterissuvis(A);       

        }
      }
      else if(pat==1)
      {sekantissuvis(A, pat1, pat2);
      }

  }
    void sekantissuvis(zaidimas A, int x, int y)
    {
      kk=1;
      kryptis=rand()%2;
      pat1=x;
      pat2=y;
      pat=1;
      if(kryptis==0)//  <-
      {  
        kryptis0(A);
      }

      else if(kryptis==1)
      { 
        kryptis1(A);    
      }
    }

    void kryptis0(zaidimas A) // <------------->
    {
      //int kk, *kkk;
      //kkk=&kk;
      //*kkk=1;

      x=pat1;
      y=pat2;
      if (kk!=0)
      while(lent[x][y-1]=='@' && y-1>=0 && kk!=0) // <-
      {  
        cout<<"\033[2J\033[1;1H";
        cout<<"Priešininkas pataikė :("<<endl;
        lent[x][y-1]='x';
          if(arsunaikintaslaivas(lent, x,y-1)!=1)//////////////////////////////////////////////
          {
            kieklaivu--;
            cout<<"Ir sunaikino visą laivą!"<<endl;
            sunaikintaslaivas(lent, x,y-1,0);
            pat=0;
          }//////////////////////////////////////////////////////////////////////////////////
        else 
        cout<<endl;
        cout<<endl<<endl<<"Mano lentelė:"<<endl;
        lentspaus();
        cout<<endl<<"Priešininko lentelė:"<<endl;
        A.lentspaus();
        sleep(2);
        if(pat==0 && kk!=0)
        {kompiuterissuvis(A);
        kk=0;}
        y--;
      }
        if(lent[x][y-1]=='.' && y-1>=0 && kk!=0) // <-
      {
        priesasnepataike(A, x, y-1);
      }
      else // ->
      {
        x=pat1;
        y=pat2;

        while(lent[x][y+1]=='@' && y+1<10 && kk!=0) // ->
        {  
          cout<<"\033[2J\033[1;1H";
          cout<<"Priešininkas pataikė :("<<endl;
          lent[x][y+1]='x';
          if(arsunaikintaslaivas(lent, x,y+1)!=1)//////////////////////////////////////////////
          {
            kieklaivu--;
            cout<<"Ir sunaikino visą laivą!"<<endl;
            sunaikintaslaivas(lent, x,y+1,0);
            pat=0;
          }//////////////////////////////////////////////////////////////////////////////////
          else
          cout<<endl;  
          cout<<endl<<endl<<"Mano lentelė:"<<endl;
          lentspaus();      
          cout<<endl<<"Priešininko lentelė:"<<endl;
          A.lentspaus();

          sleep(2);
          if(pat==0 && kk!=0)
          {kompiuterissuvis(A);
          kk=0;}
          y++;
        }
          if(pat==1 && kk!=0)
          {
          if(lent[x][y+1]=='.' && y+1<10)
          {
            priesasnepataike(A, x, y+1);
          }
          else
          if (kk!=0)
          kryptis1(A);              
          }
      


      }
    
    }
      

    void kryptis1(zaidimas A)// |||||
    {
      x=pat1;
      y=pat2;
            if(kk!=0)
      while(lent[x-1][y]=='@' && x-1>=0 && kk!=0)
      {  
        cout<<"\033[2J\033[1;1H";
        cout<<"Priešininkas pataikė :("<<endl;
        lent[x-1][y]='x';
        if(arsunaikintaslaivas(lent, x-1,y)!=1)//////////////////////////////////////////////
        {
          kieklaivu--;
          cout<<"Ir sunaikino visą laivą!"<<endl;
          sunaikintaslaivas(lent, x-1,y,0);
          pat=0;
        }//////////////////////////////////////////////////////////////////////////////////
        else
        cout<<endl;
        cout<<endl<<endl<<"Mano lentelė:"<<endl;
        lentspaus();
        cout<<endl<<"Priešininko lentelė:"<<endl;
        A.lentspaus();

        sleep(2);
        if(pat==0)
        {kompiuterissuvis(A);
        kk=0;
        }
        x--;
      }
      if(lent[x-1][y]=='.' && x-1>=0 && kk!=0)
      {
        priesasnepataike(A, x-1, y);
      }
      else
      {
        x=pat1;
        y=pat2;
        if(kk!=0)
        while(lent[x+1][y]=='@' && x+1<10)
        {  
          cout<<"\033[2J\033[1;1H";
          cout<<"Priešininkas pataikė :("<<endl;
          lent[x+1][y]='x';
          if(arsunaikintaslaivas(lent, x+1,y)!=1)//////////////////////////////////////////////
          {
            kieklaivu--;
            cout<<"Ir sunaikino visą laivą!"<<endl;
            sunaikintaslaivas(lent, x+1,y,0);
            pat=0;
          }//////////////////////////////////////////////////////////////////////////////////
          else
          cout<<endl;
          cout<<endl<<endl<<"Mano lentelė:"<<endl;
          lentspaus();
          cout<<endl<<"Priešininko lentelė:"<<endl;
          A.lentspaus();

          sleep(2);
          if(pat==0 && kk!=0)
          {kompiuterissuvis(A);
          kk=0;}
          x++;
        }
        if(pat==1)
        {
        if(lent[x+1][y]=='.' && x+1<10)
        {
          priesasnepataike(A, x+1, y);
        }
        else
        if(kk!=0)
        kryptis0(A); 
        }

      }
    }
  void suvis(zaidimas A, zaidimas & B)
  {
    cout<<endl<<"Pasirinkite taikinio koordinates"<<endl;
    cin>>x>>z;
    cout<<endl;
    z=toupper(z);
    y=z-64;

    while(!cin)//kad neleistu ivesti nesamones
    {
      cin.clear();
      cin.ignore(100, '\n');
    }
    cout<<"\033[2J\033[1;1H";
      if(x>0 && x<=10 && y>0 && y<=10)
      {
        if(lent[x-1][y-1]=='.')
        { 
          cout<<"Dėja nepataikėte"<<endl<<endl<<endl;
          lent[x-1][y-1]='o';
          B.lent[x-1][y-1]='o';//////////////////////////////////////
          cout<<"Mano lentelė:"<<endl;
          A.lentspaus();
          cout<<endl<<endl<<"Priešininko lentelė:"<<endl;
          B.lentspaus();
          sleep(1);///////////////////////////////////////////////

        }
        else if(lent[x-1][y-1]=='@')
        { 
          cout<<"Pataikėte!  ";
          lent[x-1][y-1]='x'; 
          B.lent[x-1][y-1]='x';        

          if(arsunaikintaslaivas(lent, x-1,y-1)!=1)
          {
            kieklaivu--;
            cout<<"Ir sunaikinote visą laivą!";
            sunaikintaslaivas(lent, x-1,y-1,1);
            sunaikintaslaivas(lent, x-1,y-1,1);
            sunaikintaslaivas(B.lent, x-1,y-1,1);
            sunaikintaslaivas(B.lent, x-1,y-1,1);
          }
          else
          cout<<endl;
          cout<<"Šaukite dar kartą"<<endl<<endl;
          cout<<"Mano lentelė:"<<endl;
          A.lentspaus();
          cout<<endl<<endl<<"Priešininko lentelė:"<<endl;
          B.lentspaus();
          suvis(A, B);
        }
        else
        {
          cout<<"Čia jau šovėte"<<endl<<endl;
          cout<<"Mano lentelė:"<<endl;
          A.lentspaus();
          cout<<endl<<endl<<"Priešininko lentelė:"<<endl;
          B.lentspaus();
          suvis(A,B);
        }
      }
      else
      {
        cout<<"Koordinatės negalimos"<<endl<<endl<<endl;
        cout<<"Mano lentelė:"<<endl;
        A.lentspaus();
        cout<<endl<<endl<<"Priešininko lentelė:"<<endl;
        B.lentspaus();
        suvis(A,B);
      }
    
  }
  int arsunaikintaslaivas(char M[][10], int a, int b)//pamazinta
  { 
      int v=2, z=2, d=2, k=2;
      for(int i=1;i<=4;i++)
      {
        if(a+i>=0 && a+i<10)
        {
          if(M[a+i][b]=='.' || M[a+i][b]=='o')
          {
            i=5;
            v=0;
            break;
          }
          if(M[a+i][b]=='@')
          {
            i=5;
            v=1;
          }
        }
      }
      for(int i=1;i<=4;i++)
      {
        if(a-i>=0 && a-i<10)
        {
          if(M[a-i][b]=='.' || M[a-i][b]=='o')
          {
            i=5;
            z=0;
            break;
          }
          if(M[a-i][b]=='@')
          {
            i=5;
            z=1;
          }
        }
      }
      for(int i=1;i<=4;i++)
      {
        if(b+i>=0 && b+i<10)
        {
          if(M[a][b+i]=='.' || M[a][b+i]=='o')
          {
            i=5;
            d=0;
            break;
          }
        if(M[a][b+i]=='@')
          {
            i=5;
            d=1;
          }
        }

      }
      for(int i=1;i<=4;i++)
      {
        if(b-1>=0 && b-1<10)
        {
          if(M[a][b-i]=='.' || M[a][b-i]=='o')
          {
            i=5;
            k=0;
            break;
          }
          if(M[a][b-i]=='@')
          {
            i=5;
            k=1;
          }
        }

        
      }
      if(z==1 || v==1 || d==1 || k==1)
        return 1;//nera pilnai sunaikintas
      else return 0;//sunaikintas
  }
  void sunaikintaslaivas(char M[][10], int a, int b, int c)//pamazinta
  {
      M[a][b]='X';
      
      if(M[a][b-1]=='.' && b-1>=0)
        M[a][b-1]='o';
      if(M[a][b+1]=='.' && b+1<10)
        M[a][b+1]='o';
      if(M[a-1][b]=='.' && a-1>=0)
        M[a-1][b]='o';
      if(M[a+1][b]=='.' && a+1<10)
        M[a+1][b]='o';

      if(M[a-1][b-1]=='.' && b-1>=0 && a-1>=0)
        M[a-1][b-1]='o';
      if(M[a+1][b+1]=='.' && b+1<10 && a+1<10)
        M[a+1][b+1]='o';
      if(M[a-1][b+1]=='.' && a-1>=0 && b+1<10)
        M[a-1][b+1]='o';
      if(M[a+1][b-1]=='.' && b-1>=0 && a+1<10)
        M[a+1][b-1]='o';

      if(M[a][b-1]=='x')
        sunaikintaslaivas(M, a, b-1,c);
      else if(M[a][b+1]=='x')
        sunaikintaslaivas(M, a, b+1,c);
      else if(M[a-1][b]=='x')
        sunaikintaslaivas(M, a-1, b,c);
      else if(M[a+1][b]=='x')
        sunaikintaslaivas(M, a+1, b,c);

    if(kieklaivu==0)
    {pabaiga(c);
    }
  }
  ~zaidimas()
  {}
};

class paveldeta : public zaidimas
{ 
  public:
  void niekas()
  {cout<<" ";}
  //virtual void virt() = 0;
};

int main() {
string ats;
  srand (time(0));
  zaidimas as, k(as); // k-kopija
  zaidimas kompiuteris, kompiuteris2;//matoma ir nematoma lentele

  while(ats!="t" && ats!="T" && ats!="n" && ats!="N")
  {
      cout<<"Ar norite, kad jūsų laivai būtų sudėti automatiškai? [T, N]";
      cin>>ats;
  }
  if(ats=="t" || ats=="T" )
  {
    as.laivuivedimaskompiuteris();    
  }
  else
  {
    cout<<"\033[2J\033[1;1H";
    ++as;  
  }

  kompiuteris.laivuivedimaskompiuteris();

  cout<<"\033[2J\033[1;1H";
  cout<<endl<<"ŽAIDIMAS PRASIDEDA"<<endl<<endl;
  cout<<"Mano lentelė"<<endl<<endl;
  as.lentspaus();
  cout<<"Priešininko lentelė"<<endl<<endl;
  kompiuteris2.lentspaus();

  while(true)
  { 
    kompiuteris.suvis(as, kompiuteris2);
    as.kompiuterissuvis(kompiuteris2);
  }

  }



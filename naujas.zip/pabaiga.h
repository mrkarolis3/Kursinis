using namespace std;
int pabaiga(int &a)
{
cout<<"\033[2J\033[1;1H";
if(a==1)
{
cout<<endl<<endl;
cout<<"VALIO";
cout<<endl<<endl;
cout<<" ‎       $$$$"<<endl;
cout<<"       $$  $"<<endl;
cout<<"       $   $$"<<endl;
cout<<"       $   $$"<<endl;
cout<<"       $$   $$"<<endl;
cout<<"        $    $$"<<endl;
cout<<"        $$    $$$"<<endl;
cout<<"         $$    $$"<<endl;
cout<<"         $$      $$"<<endl;
cout<<"          $       $$"<<endl;
cout<<"    $$$$$$$        $$"<<endl;
cout<<"  $$$               $$$$$$"<<endl;
cout<<" $$    $$$$            $$$"<<endl;
cout<<" $   $$$  $$$            $$"<<endl;
cout<<" $$        $$$            $"<<endl;
cout<<"  $$    $$$$$$            $"<<endl;
cout<<"  $$$$$$$    $$           $"<<endl;
cout<<"  $$       $$$$           $"<<endl;
cout<<"   $$$$$$$$$  $$         $$"<<endl;
cout<<"    $        $$$$     $$$$"<<endl;
cout<<"    $$    $$$$$$    $$$$$$"<<endl;
cout<<"     $$$$$$    $$  $$"<<endl;
cout<<"       $     $$$ $$$"<<endl;
cout<<"        $$$$$$$$$$"<<endl;
cout<<"                        "<<endl;
cout<<"                        "<<endl;  
}
if(a==0)
{
cout<<endl<<endl;
cout<<"DURNELIS ";
cout<<endl<<endl;
cout<<"           u$$$$$$$$$$$$$$$$$u           "<<endl;    
cout<<"         u$$$$$$$$$$$$$$$$$$$$$u          "<<endl;
cout<<"        u$$$$$$$$$$$$$$$$$$$$$$$u         "<<endl;
cout<<"       u$$$$$$$$$$$$$$$$$$$$$$$$$u        "<<endl;
cout<<"       u$$$$$$$$$$$$$$$$$$$$$$$$$u        "<<endl;
cout<<"       u$$$$$$”   ”$$$”   ”$$$$$$u        "<<endl;
cout<<"       ”$$$$”      u$u       $$$$”        "<<endl;
cout<<"        $$$   u$u       u$$$              "<<endl;
cout<<"        $$$u      u$$$u      u$$$         "<<endl;
cout<<"         ”$$$$uu$$$   $$$uu$$$$”          "<<endl;
cout<<"          ”$$$$$$$”   ”$$$$$$$”           "<<endl;
cout<<"            u$$$$$$$u$$$$$$$u             "<<endl;
cout<<"             u$”$”$”$”$”$”$u              "<<endl;
cout<<"  uu         $$u$_$_$_$_$u$$       uuu    "<<endl;
cout<<" u$$$$        $$$$$u$u$u$$$       u$$$$   "<<endl;
cout<<"  $$$$$uu      ”$$$$$$$$$”     uu$$$$$$   "<<endl;
cout<<"u$$$$$$$$$$$uu    ”””””    uuuu$$$$$$$$$$ "<<endl;
cout<<"$$$$”””$$$$$$$$$$uuu   uu$$$$$$$$$”””$$$” "<<endl;
cout<<" ”””      ””$$$$$$$$$$$uu ””$””           "<<endl;
cout<<"           uuuu ””$$$$$$$$$$uuu           "<<endl;
cout<<"  u$$$uuu$$$$$$$$$uu ””$$$$$$$$$$$uuu$$$  "<<endl;
cout<<"  $$$$$$$$$$””””           ””$$$$$$$$$$$” "<<endl;
cout<<"   ”$$$$$”                      ””$$$$””  "<<endl;

}

exit(0);
}